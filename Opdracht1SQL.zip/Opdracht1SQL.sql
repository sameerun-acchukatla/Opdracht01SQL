CREATE  DATABASE IF NOT EXISTS TheBelgianBreweryDB;

Use TheBelgianBreweryDB;

-- OPDRACHT

-- (a) Geef een lijst van alle biercategorieen. (38)

SELECT * from categories;

-- (b) Toon de lijst van categorieen in dalende alfabetische
--      volgorde zonder de categorie-id’s. (38)

-- SELECT ColumnName1,...,ColumnNameN FROM TableName  ORDER BY ColumnNameDESC;
SELECT Category FROM Categories ORDER BY  Category DESC;

-- (c) Toon een lijst van alle brouwerijen die meer dan 5000 Euro
--     turnover hebben. (54)

SELECT Id,
       Name,
       Address,
       ZipCode,
       City
FROM Brewers
WHERE Turnover > 5000;

-- (d) Toon nu enkel de naam en de stad van de brouwerijen die
--    minder dan 5000 Euro turnover, maar niet 0. Sorteer de lijst op basis van de turnover.(53)

SELECT Name,
       City
FROM Brewers
WHERE  Turnover > 0 AND Turnover < 5000 ORDER BY Turnover;

-- (e) Geef een lijst van alle mogelijke alcoholgehaltes in de
--    beers tabel. Dus geen dubbels. En gesorteerd van groot naar klein. (14)

-- SELECT DISTINCT column_name ,column_name  FROM  table_name;

SELECT DISTINCT Alcohol from Beers ORDER BY Alcohol DESC ;

-- (f) Toon alle namen van bieren waarvan de naam “wit” bevat
--     zonder dubbels, alfabetisch gesorteerd. (30)

SELECT DISTINCT Name FROM beers
WHERE Name LIKE '%wit%'
ORDER BY  Name ;

-- (g) Toon alle bieren met meer alcohol dan 3 en minder dan 7
--     zonder gebruik te maken van logische operatoren (<, >, …)(568)

SELECT * FROM Beers WHERE Alcohol BETWEEN 4 AND 6;

-- (h) Geef de top 3 van de sterkste bieren in onze database. (3)

SELECT * FROM Beers
ORDER BY Alcohol DESC LIMIT 3;

-- (i) Doordenker: Maak een lijst van de naam, straat, postcode en
-- stad voor alle brouwers in 3 kolommen voor een adressenlijst.
-- M.a.w. combineer de postcode en de stad in 1 kolom.

SELECT Name,Address, CONCAT(City,'  ',ZipCode)  AS 'City_Zipcode' FROM brewers;

